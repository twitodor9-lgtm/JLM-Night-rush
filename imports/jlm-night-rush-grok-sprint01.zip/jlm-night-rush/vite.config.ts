import { defineConfig } from 'vite';
import { viteSingleFile } from 'vite-plugin-singlefile';

// SINGLEFILE=1 -> one self-contained dist/index.html (map JSON + Rapier WASM inlined),
// opens with a double click (file://). Normal build -> hostable static site (GitHub Pages).
export default defineConfig({
  base: './',
  plugins: process.env.SINGLEFILE ? [viteSingleFile()] : [],
  build: { target: 'es2022', chunkSizeWarningLimit: 4000 },
  test: { environment: 'node' },
});
