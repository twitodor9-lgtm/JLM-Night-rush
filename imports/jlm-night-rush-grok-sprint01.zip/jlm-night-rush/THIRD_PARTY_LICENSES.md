# Third-party licenses
- three.js — MIT — https://github.com/mrdoob/three.js
- Rapier (@dimforge/rapier3d-compat) — Apache-2.0 — https://github.com/dimforge/rapier
- Vite, Vitest, TypeScript, vite-plugin-singlefile — MIT / Apache-2.0 (dev tools)
- Map data: © OpenStreetMap contributors, ODbL 1.0 — https://www.openstreetmap.org/copyright (must be credited in any shipped build)
- Elevation: Copernicus DEM GLO-90 via Open-Meteo (check Open-Meteo terms for non-commercial/commercial use before release)
- Costa Vista (fastrouter/experiments-costa-vista) — MIT — **no code ported yet**. If ported, add the original copyright notice and MIT text here.
- Textures and the car model are procedural/original in this repo (no commercial assets).
