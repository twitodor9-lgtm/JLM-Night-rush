// Converts data/raw/osm-raw.json -> src/data/maps/jerusalem-first-station.json (GameMap format).
// Flags: --no-elevation  skip DEM sampling.
import fs from 'node:fs';
const cfg = JSON.parse(fs.readFileSync(new URL('./area.config.json', import.meta.url)));
const raw = JSON.parse(fs.readFileSync('data/raw/osm-raw.json', 'utf8'));
const KX = 111320 * Math.cos(cfg.lat * Math.PI / 180), KZ = 110574;
const proj = (p) => [+((p.lon - cfg.lon) * KX).toFixed(2), +(-(p.lat - cfg.lat) * KZ).toFixed(2)];
const KIND = { motorway: 'motorway', trunk: 'primary', primary: 'primary', secondary: 'secondary', tertiary: 'tertiary', residential: 'residential', unclassified: 'residential', living_street: 'residential', service: 'service', pedestrian: 'pedestrian' };
const WIDTH = { motorway: 14, primary: 12, secondary: 10, tertiary: 9, residential: 7, service: 4.5, pedestrian: 6 };
const hash = (id) => { let h = id * 2654435761 % 4294967296; return (h >>> 0) / 4294967296; };

const roads = [], buildings = [];
for (const el of raw.elements) {
  if (el.type !== 'way' || !el.geometry || el.geometry.length < 2) continue;
  const t = el.tags || {};
  if (t.highway) {
    const kind = KIND[String(t.highway).replace('_link', '')];
    if (!kind) continue;
    const lanes = parseInt(t.lanes);
    const width = t.width && parseFloat(t.width) > 2 ? parseFloat(t.width) : lanes ? Math.max(lanes * 3.2, 4.5) : WIDTH[kind];
    roads.push({ id: el.id, kind, name: t.name, width, oneway: t.oneway === 'yes' || t.junction === 'roundabout', roundabout: t.junction === 'roundabout' || undefined, points: el.geometry.map(proj) });
  } else if (t.building && el.geometry.length >= 4) {
    let height, heightSource;
    if (t.height && parseFloat(t.height) > 0) { height = parseFloat(t.height); heightSource = 'osm'; }
    else if (t['building:levels'] && parseFloat(t['building:levels']) > 0) { height = parseFloat(t['building:levels']) * 3.2 + 1; heightSource = 'levels'; }
    else { height = +(7 + hash(el.id) * 14).toFixed(1); heightSource = 'guess'; } // NOT real data
    buildings.push({ id: el.id, height, heightSource, footprint: el.geometry.map(proj) });
  }
}

let elevation;
if (cfg.elevation?.enabled && !process.argv.includes('--no-elevation')) {
  // Open-Meteo elevation API (Copernicus GLO-90, ~90 m native resolution => coarse; see KNOWN_ISSUES).
  const cell = cfg.elevation.gridCellMeters, R = cfg.radiusMeters + 120;
  const cols = Math.floor((2 * R) / cell) + 1, rows = cols, minX = -R, minZ = -R;
  const pts = [];
  for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
    const x = minX + i * cell, z = minZ + j * cell;
    pts.push([cfg.lat - z / KZ, cfg.lon + x / KX]);
  }
  const out = [];
  try {
    for (let k = 0; k < pts.length; k += 100) {
      const c = pts.slice(k, k + 100);
      const url = `https://api.open-meteo.com/v1/elevation?latitude=${c.map((p) => p[0].toFixed(5)).join(',')}&longitude=${c.map((p) => p[1].toFixed(5)).join(',')}`;
      const r = await fetch(url); if (!r.ok) throw new Error('HTTP ' + r.status);
      out.push(...(await r.json()).elevation);
    }
    const base = out[Math.floor(out.length / 2)];
    elevation = { minX, minZ, cell, cols, rows, data: out.map((v) => +(v - base).toFixed(2)), source: 'Open-Meteo / Copernicus DEM GLO-90 (~90 m)' };
  } catch (e) { console.warn('Elevation failed, continuing flat:', e.message); }
}

const map = {
  meta: { name: cfg.name, synthetic: false, origin: { lat: cfg.lat, lon: cfg.lon }, source: 'OpenStreetMap contributors (Overpass API snapshot)', license: 'ODbL 1.0 - https://www.openstreetmap.org/copyright', generated: new Date().toISOString(), notes: 'Building heights with heightSource=guess are placeholders.' },
  roads, buildings, ...(elevation ? { elevation } : {}),
};
fs.mkdirSync('src/data/maps', { recursive: true });
fs.writeFileSync('src/data/maps/jerusalem-first-station.json', JSON.stringify(map));
const g = buildings.filter((b) => b.heightSource === 'guess').length;
console.log(`roads ${roads.length}, buildings ${buildings.length} (${g} with guessed height), elevation ${elevation ? 'yes' : 'no (flat)'}`);
