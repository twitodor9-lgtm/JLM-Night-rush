#!/usr/bin/env bash
# Puts this code on a NEW branch of the repo. Never touches main or feature/engine-v0.8-foundation.
set -e
git clone https://github.com/twitodor9-lgtm/JLM-Night-rush.git ../JLM-Night-rush-claude
cd ../JLM-Night-rush-claude
git checkout -b feature/claude-engine-v1 origin/main   # branch from main; change if you prefer another base
rsync -a --exclude node_modules --exclude .git ../jlm-night-rush/ ./claude-engine-v1/
git add . && git commit -m "feat: Claude engine v1 foundation (Three+Rapier, OSM pipeline)"
git push -u origin feature/claude-engine-v1
echo "Now open a Pull Request on GitHub (do not merge)."
