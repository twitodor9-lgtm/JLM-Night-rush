// DEV-TIME ONLY. Downloads real OpenStreetMap data once and stores it in data/raw/osm-raw.json.
// The game never calls Overpass at runtime. Requires Node 18+ and internet.
import fs from 'node:fs';
const cfg = JSON.parse(fs.readFileSync(new URL('./area.config.json', import.meta.url)));
const dLat = cfg.radiusMeters / 110574, dLon = cfg.radiusMeters / (111320 * Math.cos(cfg.lat * Math.PI / 180));
const bbox = [cfg.lat - dLat, cfg.lon - dLon, cfg.lat + dLat, cfg.lon + dLon].map((v) => v.toFixed(6)).join(',');
const q = `[out:json][timeout:60];(way["highway"~"^(motorway|trunk|primary|secondary|tertiary|residential|unclassified|living_street|service|pedestrian)(_link)?$"](${bbox});way["building"](${bbox}););out geom tags;`;
const endpoints = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter'];
let data;
for (const ep of endpoints) {
  try {
    console.log('Querying', ep, 'bbox', bbox);
    const res = await fetch(ep, { method: 'POST', body: 'data=' + encodeURIComponent(q), headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    data = await res.json(); break;
  } catch (e) { console.warn('failed:', e.message); }
}
if (!data) { console.error('All Overpass endpoints failed.'); process.exit(1); }
fs.mkdirSync('data/raw', { recursive: true });
fs.writeFileSync('data/raw/osm-raw.json', JSON.stringify(data));
console.log(`Saved data/raw/osm-raw.json (${data.elements.length} elements). Data (c) OpenStreetMap contributors, ODbL.`);
