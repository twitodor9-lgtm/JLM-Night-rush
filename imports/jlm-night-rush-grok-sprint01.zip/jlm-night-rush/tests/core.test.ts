import { describe, it, expect } from 'vitest';
import { LocalProjection } from '../src/world/projection';
import { RoadNetwork } from '../src/world/roadNetwork';
import { Terrain } from '../src/world/terrain';
import { validateMap } from '../src/world/validate';
import { DEFAULT_TUNING, TUNING_FIELDS } from '../src/vehicle/tuning';
import synthetic from '../src/data/maps/synthetic-test-map.json';

describe('projection', () => {
  it('round-trips', () => {
    const p = new LocalProjection(31.7655, 35.2208);
    const [x, z] = p.toLocal(31.767, 35.222);
    const [lat, lon] = p.toGeo(x, z);
    expect(lat).toBeCloseTo(31.767, 6); expect(lon).toBeCloseTo(35.222, 6);
  });
  it('north is -z, east is +x', () => {
    const p = new LocalProjection(31, 35);
    expect(p.toLocal(31.001, 35)[1]).toBeLessThan(0);
    expect(p.toLocal(31, 35.001)[0]).toBeGreaterThan(0);
  });
});
describe('road network', () => {
  const net = new RoadNetwork({ roads: [
    { id: 1, kind: 'tertiary', width: 8, oneway: false, points: [[0, 0], [100, 0]] },
    { id: 2, kind: 'tertiary', width: 8, oneway: false, points: [[100, 0], [100, 100]] },
  ] });
  it('connects ways at shared vertices', () => expect(net.componentCount()).toBe(1));
  it('finds nearest road', () => { const n = net.nearestRoad(50, 5)!; expect(n.road.id).toBe(1); expect(n.distance).toBeCloseTo(5); });
});
describe('terrain', () => {
  it('bilinear', () => {
    const t = new Terrain({ minX: 0, minZ: 0, cell: 10, cols: 2, rows: 2, data: [0, 10, 0, 10] });
    expect(t.heightAt(5, 5)).toBeCloseTo(5); expect(t.heightAt(-50, 0)).toBeCloseTo(0);
  });
  it('flat without data', () => expect(new Terrain().heightAt(3, 4)).toBe(0));
});
describe('map + tuning', () => {
  it('synthetic map validates and is flagged synthetic', () => { expect(validateMap(synthetic)).toEqual([]); expect(synthetic.meta.synthetic).toBe(true); });
  it('synthetic map network is one component', () => expect(new RoadNetwork(synthetic as never).componentCount()).toBe(1));
  it('tuning defaults within slider ranges', () => {
    for (const f of TUNING_FIELDS) { const v = DEFAULT_TUNING[f.key]; expect(v).toBeGreaterThanOrEqual(f.min); expect(v).toBeLessThanOrEqual(f.max); }
  });
});
