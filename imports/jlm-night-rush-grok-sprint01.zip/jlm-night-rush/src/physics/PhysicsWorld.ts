import RAPIER from '@dimforge/rapier3d-compat';

export const STEP = 1 / 60;

export class PhysicsWorld {
  readonly R = RAPIER;
  world!: RAPIER.World;
  static async create(): Promise<PhysicsWorld> {
    await RAPIER.init();
    const p = new PhysicsWorld();
    p.world = new RAPIER.World({ x: 0, y: -9.81, z: 0 });
    p.world.timestep = STEP;
    return p;
  }
  addStaticTrimesh(vertices: Float32Array, indices: Uint32Array, friction = 1.0) {
    if (vertices.length === 0) return;
    const body = this.world.createRigidBody(RAPIER.RigidBodyDesc.fixed());
    this.world.createCollider(RAPIER.ColliderDesc.trimesh(vertices, indices).setFriction(friction), body);
  }
  step() { this.world.step(); }
}
