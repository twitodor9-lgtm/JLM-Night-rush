import * as THREE from 'three';

/** Yaw-only smoothed chase camera (does not roll/pitch with the car body). */
export class ChaseCamera {
  private dir = new THREE.Vector3(0, 0, 1);
  private pos = new THREE.Vector3();
  private inited = false;
  distance = 8.5; height = 3.4; stiffness = 5;

  constructor(public camera: THREE.PerspectiveCamera) {}

  update(dt: number, target: THREE.Object3D, forward: { x: number; z: number }, speedKmh: number) {
    const f = new THREE.Vector3(forward.x, 0, forward.z);
    if (f.lengthSq() > 1e-4) f.normalize(); else f.copy(this.dir);
    if (!this.inited) { this.dir.copy(f); this.inited = true; }
    this.dir.lerp(f, 1 - Math.exp(-3 * dt)).normalize();
    const d = this.distance + Math.min(speedKmh / 60, 2.5);
    const want = target.position.clone().addScaledVector(this.dir, -d).add(new THREE.Vector3(0, this.height, 0));
    if (this.pos.lengthSq() === 0) this.pos.copy(want);
    this.pos.lerp(want, 1 - Math.exp(-this.stiffness * dt));
    this.camera.position.copy(this.pos);
    this.camera.lookAt(target.position.clone().addScaledVector(this.dir, 5).add(new THREE.Vector3(0, 1.0, 0)));
    this.camera.fov = 62 + Math.min(speedKmh / 8, 14);
    this.camera.updateProjectionMatrix();
  }
}
