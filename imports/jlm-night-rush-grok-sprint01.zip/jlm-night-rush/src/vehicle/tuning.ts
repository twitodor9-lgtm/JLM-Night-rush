export interface VehicleTuning {
  mass: number; engineForce: number; brakeForce: number; handbrakeForce: number; maxSpeedKmh: number;
  maxSteer: number; steerFalloffKmh: number; steerRate: number;
  suspensionRestLength: number; suspensionStiffness: number; suspensionCompression: number; suspensionRelaxation: number;
  maxSuspensionTravel: number; maxSuspensionForce: number;
  frictionSlip: number; rearFrictionSlipHandbrake: number; sideFrictionStiffness: number;
  downforce: number; linearDamping: number; angularDamping: number;
  /** Sign flips: verify in browser on first run (Rapier axis conventions). */
  driveSign: number; steerSign: number;
}
export const DEFAULT_TUNING: VehicleTuning = {
  mass: 1200, engineForce: 6000, brakeForce: 60, handbrakeForce: 120, maxSpeedKmh: 180,
  maxSteer: 0.55, steerFalloffKmh: 90, steerRate: 8,
  suspensionRestLength: 0.45, suspensionStiffness: 28, suspensionCompression: 2.4, suspensionRelaxation: 3.0,
  maxSuspensionTravel: 0.35, maxSuspensionForce: 60000,
  frictionSlip: 3.2, rearFrictionSlipHandbrake: 0.9, sideFrictionStiffness: 1.0,
  downforce: 2.5, linearDamping: 0.05, angularDamping: 0.6,
  driveSign: 1, steerSign: -1,
};
export interface TuningField { key: keyof VehicleTuning; label: string; min: number; max: number; step: number }
export const TUNING_FIELDS: TuningField[] = [
  { key: 'mass', label: 'Mass (kg)', min: 600, max: 3000, step: 50 },
  { key: 'engineForce', label: 'Engine force', min: 1000, max: 15000, step: 100 },
  { key: 'brakeForce', label: 'Brake force', min: 5, max: 200, step: 5 },
  { key: 'handbrakeForce', label: 'Handbrake force', min: 5, max: 300, step: 5 },
  { key: 'maxSpeedKmh', label: 'Max speed (km/h)', min: 60, max: 300, step: 5 },
  { key: 'maxSteer', label: 'Max steer (rad)', min: 0.2, max: 0.9, step: 0.01 },
  { key: 'steerFalloffKmh', label: 'Steer falloff (km/h)', min: 30, max: 200, step: 5 },
  { key: 'suspensionStiffness', label: 'Susp. stiffness', min: 8, max: 80, step: 1 },
  { key: 'suspensionCompression', label: 'Susp. compression', min: 0.5, max: 8, step: 0.1 },
  { key: 'suspensionRelaxation', label: 'Susp. relaxation', min: 0.5, max: 8, step: 0.1 },
  { key: 'frictionSlip', label: 'Tyre grip', min: 0.5, max: 8, step: 0.1 },
  { key: 'rearFrictionSlipHandbrake', label: 'Rear grip (handbrake)', min: 0.1, max: 4, step: 0.05 },
  { key: 'downforce', label: 'Downforce', min: 0, max: 10, step: 0.25 },
  { key: 'angularDamping', label: 'Angular damping', min: 0, max: 3, step: 0.05 },
  { key: 'driveSign', label: 'Drive sign (±1)', min: -1, max: 1, step: 2 },
  { key: 'steerSign', label: 'Steer sign (±1)', min: -1, max: 1, step: 2 },
];
