import * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';
import type { PhysicsWorld } from '../physics/PhysicsWorld';
import type { ControlState } from '../input/Input';
import type { VehicleTuning } from './tuning';

// Local frame: +Z forward, +Y up, -X is the wheel axle direction (Rapier raycast vehicle convention).
const HALF = { x: 0.9, y: 0.35, z: 2.1 };
const WHEEL_R = 0.36;
const WHEELS = [
  { x: 0.8, y: -0.15, z: 1.35, front: true },
  { x: -0.8, y: -0.15, z: 1.35, front: true },
  { x: 0.8, y: -0.15, z: -1.3, front: false },
  { x: -0.8, y: -0.15, z: -1.3, front: false },
];

export class Vehicle {
  object = new THREE.Group();
  body: RAPIER.RigidBody;
  private controller: RAPIER.DynamicRayCastVehicleController;
  private collider: RAPIER.Collider;
  private wheelMeshes: THREE.Group[] = [];
  private steer = 0;
  speedKmh = 0; fwdSpeed = 0;
  readonly headlight: THREE.SpotLight;

  constructor(private physics: PhysicsWorld, public tuning: VehicleTuning, private spawn: { x: number; y: number; z: number; yaw: number }) {
    const R = physics.R, w = physics.world;
    const q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), spawn.yaw);
    this.body = w.createRigidBody(R.RigidBodyDesc.dynamic()
      .setTranslation(spawn.x, spawn.y, spawn.z).setRotation({ x: q.x, y: q.y, z: q.z, w: q.w }).setCanSleep(false)
      .setCcdEnabled(true));
    this.collider = w.createCollider(R.ColliderDesc.cuboid(HALF.x, HALF.y, HALF.z).setMass(tuning.mass).setFriction(0.2), this.body);
    this.controller = w.createVehicleController(this.body);
    WHEELS.forEach((wh) => {
      this.controller.addWheel({ x: wh.x, y: wh.y, z: wh.z }, { x: 0, y: -1, z: 0 }, { x: -1, y: 0, z: 0 }, tuning.suspensionRestLength, WHEEL_R);
    });
    this.applyTuning(tuning);
    this.buildMesh();
    this.headlight = new THREE.SpotLight(0xfff2cc, 0, 90, 0.6, 0.5, 1.2);
    this.headlight.position.set(0, 0.2, 2.0);
    this.headlight.target.position.set(0, -0.5, 25);
    this.object.add(this.headlight, this.headlight.target);
  }

  applyTuning(t: VehicleTuning) {
    this.tuning = t;
    this.collider.setMass(t.mass);
    this.body.setLinearDamping(t.linearDamping);
    this.body.setAngularDamping(t.angularDamping);
    for (let i = 0; i < 4; i++) {
      const c = this.controller;
      c.setWheelSuspensionRestLength(i, t.suspensionRestLength);
      c.setWheelSuspensionStiffness(i, t.suspensionStiffness);
      c.setWheelSuspensionCompression(i, t.suspensionCompression);
      c.setWheelSuspensionRelaxation(i, t.suspensionRelaxation);
      c.setWheelMaxSuspensionTravel(i, t.maxSuspensionTravel);
      c.setWheelMaxSuspensionForce(i, t.maxSuspensionForce);
      c.setWheelFrictionSlip(i, t.frictionSlip);
      c.setWheelSideFrictionStiffness(i, t.sideFrictionStiffness);
    }
  }

  private buildMesh() {
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.55, 4.2), new THREE.MeshStandardMaterial({ color: 0xd62f2f, metalness: 0.5, roughness: 0.35 }));
    body.castShadow = true;
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.5, 2.0), new THREE.MeshStandardMaterial({ color: 0x1b2430, metalness: 0.7, roughness: 0.2 }));
    cabin.position.set(0, 0.5, -0.2); cabin.castShadow = true;
    this.object.add(body, cabin);
    const wg = new THREE.CylinderGeometry(WHEEL_R, WHEEL_R, 0.28, 18); wg.rotateZ(Math.PI / 2);
    const wm = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9 });
    WHEELS.forEach(() => {
      const g = new THREE.Group(); const m = new THREE.Mesh(wg, wm); m.castShadow = true; g.add(m);
      g.rotation.order = 'YXZ'; this.object.add(g); this.wheelMeshes.push(g);
    });
  }

  /** Call once per fixed physics step, BEFORE world.step(). */
  preStep(dt: number, c: ControlState) {
    const t = this.tuning, q = this.body.rotation(), v = this.body.linvel();
    const fwd = new THREE.Vector3(0, 0, 1).applyQuaternion(new THREE.Quaternion(q.x, q.y, q.z, q.w));
    this.fwdSpeed = v.x * fwd.x + v.y * fwd.y + v.z * fwd.z;
    this.speedKmh = Math.hypot(v.x, v.y, v.z) * 3.6;

    let engine = 0, brake = 0;
    if (c.throttle > 0) { if (this.fwdSpeed < -1) brake = t.brakeForce; else engine = t.engineForce; }
    if (c.brake > 0) { if (this.fwdSpeed > 1) brake = t.brakeForce; else engine = -t.engineForce * 0.55; }
    if (this.fwdSpeed * 3.6 > t.maxSpeedKmh && engine > 0) engine = 0;
    if (this.fwdSpeed * 3.6 < -t.maxSpeedKmh * 0.35 && engine < 0) engine = 0;

    const k = Math.min(Math.abs(this.fwdSpeed) * 3.6 / t.steerFalloffKmh, 1);
    const target = c.steer * t.maxSteer * (1 - 0.7 * k);
    this.steer += (target - this.steer) * Math.min(1, dt * t.steerRate);

    for (let i = 0; i < 4; i++) {
      const front = WHEELS[i].front;
      this.controller.setWheelSteering(i, front ? this.steer * t.steerSign : 0);
      this.controller.setWheelEngineForce(i, front ? 0 : engine * t.driveSign); // RWD
      let b = brake;
      if (!front && c.handbrake) b = Math.max(b, t.handbrakeForce);
      this.controller.setWheelBrake(i, b);
      this.controller.setWheelFrictionSlip(i, !front && c.handbrake ? t.rearFrictionSlipHandbrake : t.frictionSlip);
    }
    this.controller.updateVehicle(dt);

    this.body.resetForces(true);
    const f = t.downforce * this.speedKmh * 0.28 * (t.mass / 1200);
    this.body.addForce({ x: 0, y: -f, z: 0 }, true);
  }

  /** Copy physics state to meshes. */
  sync() {
    const p = this.body.translation(), q = this.body.rotation();
    this.object.position.set(p.x, p.y, p.z);
    this.object.quaternion.set(q.x, q.y, q.z, q.w);
    this.wheelMeshes.forEach((g, i) => {
      const len = this.controller.wheelSuspensionLength(i) ?? this.tuning.suspensionRestLength;
      g.position.set(WHEELS[i].x, WHEELS[i].y - len, WHEELS[i].z);
      g.rotation.y = WHEELS[i].front ? this.steer * this.tuning.steerSign : 0;
      g.rotation.x = this.controller.wheelRotation(i) ?? 0;
    });
  }

  heading(): { x: number; z: number } {
    const q = this.body.rotation();
    const f = new THREE.Vector3(0, 0, 1).applyQuaternion(new THREE.Quaternion(q.x, q.y, q.z, q.w));
    return { x: f.x, z: f.z };
  }

  reset() {
    const q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), this.spawn.yaw);
    this.body.setTranslation({ x: this.spawn.x, y: this.spawn.y, z: this.spawn.z }, true);
    this.body.setRotation({ x: q.x, y: q.y, z: q.z, w: q.w }, true);
    this.body.setLinvel({ x: 0, y: 0, z: 0 }, true);
    this.body.setAngvel({ x: 0, y: 0, z: 0 }, true);
    this.body.resetForces(true);
    this.body.resetTorques(true);
    this.steer = 0;
    this.speedKmh = 0;
    this.fwdSpeed = 0;
    // Clear wheel forces so the next preStep starts clean
    for (let i = 0; i < 4; i++) {
      this.controller.setWheelEngineForce(i, 0);
      this.controller.setWheelBrake(i, 0);
      this.controller.setWheelSteering(i, 0);
    }
  }

  /** Auto-flip recovery helper: true if the car is mostly upside down. */
  isFlipped(): boolean {
    const q = this.body.rotation();
    return new THREE.Vector3(0, 1, 0).applyQuaternion(new THREE.Quaternion(q.x, q.y, q.z, q.w)).y < 0.2;
  }
}
