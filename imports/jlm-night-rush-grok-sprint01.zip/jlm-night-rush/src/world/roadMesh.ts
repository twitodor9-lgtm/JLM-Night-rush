import * as THREE from 'three';
import type { XZ } from './types';
import type { Terrain } from './terrain';

export interface RibbonOpts {
  width: number; lateral: number; y: number; uScale: number; vScale: number; terrain: Terrain;
}
/** Builds a flat ribbon along a polyline, draped on the terrain. Winding faces +Y. */
export function buildRibbon(pts: XZ[], o: RibbonOpts): { pos: number[]; uv: number[]; idx: number[] } {
  const pos: number[] = [], uv: number[] = [], idx: number[] = [];
  const n = pts.length;
  const segN: XZ[] = [];
  for (let i = 0; i < n - 1; i++) {
    const dx = pts[i + 1][0] - pts[i][0], dz = pts[i + 1][1] - pts[i][1], l = Math.hypot(dx, dz) || 1;
    segN.push([-dz / l, dx / l]);
  }
  let dist = 0;
  for (let i = 0; i < n; i++) {
    const a = segN[Math.max(i - 1, 0)], b = segN[Math.min(i, n - 2)];
    let nx = a[0] + b[0], nz = a[1] + b[1];
    const l = Math.hypot(nx, nz) || 1; nx /= l; nz /= l;
    const miter = Math.min(1 / Math.max(nx * b[0] + nz * b[1], 0.5), 2);
    const [px, pz] = pts[i];
    if (i > 0) dist += Math.hypot(px - pts[i - 1][0], pz - pts[i - 1][1]);
    for (const side of [1, -1]) {
      const off = (o.lateral + (side * o.width) / 2) * miter;
      const x = px + nx * off, z = pz + nz * off;
      pos.push(x, o.terrain.heightAt(x, z) + o.y, z);
      uv.push(side === 1 ? 0 : o.width * o.uScale, dist * o.vScale);
    }
    if (i < n - 1) { const k = i * 2; idx.push(k, k + 2, k + 1, k + 1, k + 2, k + 3); }
  }
  return { pos, uv, idx };
}

export function ribbonGeometry(parts: { pos: number[]; uv: number[]; idx: number[] }[]): THREE.BufferGeometry {
  const pos: number[] = [], uv: number[] = [], idx: number[] = [];
  let base = 0;
  for (const p of parts) {
    pos.push(...p.pos); uv.push(...p.uv);
    for (const i of p.idx) idx.push(i + base);
    base += p.pos.length / 3;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}
