const M_PER_DEG_LAT = 110574;
const M_PER_DEG_LON_EQ = 111320;

/** Local equirectangular projection. +x east, -z north (so north is "up" on a top-down view). */
export class LocalProjection {
  private kx: number;
  constructor(public lat0: number, public lon0: number) {
    this.kx = M_PER_DEG_LON_EQ * Math.cos((lat0 * Math.PI) / 180);
  }
  toLocal(lat: number, lon: number): [number, number] {
    return [(lon - this.lon0) * this.kx, -(lat - this.lat0) * M_PER_DEG_LAT];
  }
  toGeo(x: number, z: number): [number, number] {
    return [this.lat0 - z / M_PER_DEG_LAT, this.lon0 + x / this.kx];
  }
}
