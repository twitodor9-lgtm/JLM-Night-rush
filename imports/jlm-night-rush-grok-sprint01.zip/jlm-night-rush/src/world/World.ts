import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { GameMap, RoadKind, XZ } from './types';
import { RoadNetwork } from './roadNetwork';
import { Terrain } from './terrain';
import { buildRibbon, ribbonGeometry } from './roadMesh';
import { asphaltTexture, dashTexture, facadeTexture, stoneTexture } from './textures';

const KIND_RANK: Record<RoadKind, number> = { service: 0, pedestrian: 1, residential: 2, tertiary: 3, secondary: 4, primary: 5, motorway: 6 };
export interface TriMesh { vertices: Float32Array; indices: Uint32Array }

/** Builds render meshes and collision meshes from ONE GameMap (+ RoadNetwork). */
export class World {
  group = new THREE.Group();
  network: RoadNetwork;
  terrain: Terrain;
  groundCollider!: TriMesh;
  buildingCollider!: TriMesh;
  lampMaterial: THREE.MeshStandardMaterial;
  stats = { roads: 0, buildings: 0, lamps: 0, buildingsDroppedDegenerate: 0 };

  constructor(public map: GameMap, lampMaterial: THREE.MeshStandardMaterial) {
    this.lampMaterial = lampMaterial;
    this.network = new RoadNetwork(map);
    this.terrain = new Terrain(map.elevation);
    this.buildGround();
    this.buildRoads();
    this.buildBuildings();
    this.buildLamps();
  }

  private buildGround() {
    const b = this.network.bounds, m = 120;
    const { geometry, vertices, indices } = this.terrain.buildGeometry({ minX: b.minX - m, maxX: b.maxX + m, minZ: b.minZ - m, maxZ: b.maxZ + m }, 8);
    const tex = stoneTexture('#a89878'); tex.repeat.set(1, 1);
    const mesh = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ map: tex, roughness: 1 }));
    mesh.receiveShadow = true;
    this.group.add(mesh);
    this.groundCollider = { vertices, indices };
  }

  private buildRoads() {
    const asphalt = asphaltTexture();
    const stone = stoneTexture();
    const dash = dashTexture();
    const roadMat = new THREE.MeshStandardMaterial({ map: asphalt, roughness: 0.95, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    const walkMat = new THREE.MeshStandardMaterial({ map: stone, roughness: 0.9 });
    const lineMat = new THREE.MeshBasicMaterial({ map: dash, transparent: true, alphaTest: 0.5, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 });
    const road: ReturnType<typeof buildRibbon>[] = [], walk: typeof road = [], lines: typeof road = [];
    for (const r of this.map.roads) {
      const y = 0.06 + KIND_RANK[r.kind] * 0.012;
      road.push(buildRibbon(r.points, { width: r.width, lateral: 0, y, uScale: 1 / 4, vScale: 1 / 4, terrain: this.terrain }));
      if (r.kind !== 'service' && r.kind !== 'pedestrian') {
        for (const s of [1, -1]) walk.push(buildRibbon(r.points, { width: 2.4, lateral: s * (r.width / 2 + 1.2), y: 0.04, uScale: 1 / 2, vScale: 1 / 2, terrain: this.terrain }));
      }
      if (r.width >= 7 && r.kind !== 'pedestrian') {
        lines.push(buildRibbon(r.points, { width: 0.18, lateral: 0, y: y + 0.01, uScale: 1, vScale: 1 / 6, terrain: this.terrain }));
      }
    }
    const rm = new THREE.Mesh(ribbonGeometry(road), roadMat); rm.receiveShadow = true;
    const wm = new THREE.Mesh(ribbonGeometry(walk), walkMat); wm.receiveShadow = true;
    const lm = new THREE.Mesh(ribbonGeometry(lines), lineMat); lm.renderOrder = 2;
    this.group.add(rm, wm, lm);
    this.stats.roads = this.map.roads.length;
  }

  private buildBuildings() {
    const tints = ['#d8c29a', '#cdb68c', '#e0cfae'];
    const mats = tints.map((t) => {
      const tex = facadeTexture(t); tex.repeat.set(1 / 4, 1 / 4);
      return new THREE.MeshStandardMaterial({ map: tex, roughness: 0.9 });
    });
    const groups: THREE.BufferGeometry[][] = [[], [], []];
    const colPos: number[] = [];
    for (const b of this.map.buildings) {
      let pts = b.footprint.slice();
      if (pts.length > 1 && pts[0][0] === pts[pts.length - 1][0] && pts[0][1] === pts[pts.length - 1][1]) pts.pop();
      if (pts.length < 3) { this.stats.buildingsDroppedDegenerate++; continue; }
      let minH = Infinity;
      for (const [x, z] of pts) minH = Math.min(minH, this.terrain.heightAt(x, z));
      const shape = new THREE.Shape(pts.map(([x, z]) => new THREE.Vector2(x, -z)));
      const depth = b.height + 1;
      const g = new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: false });
      g.rotateX(-Math.PI / 2);
      g.translate(0, minH - 1, 0);
      // Non-indexed for correct sequential trimesh (Rapier expects valid triangles)
      const ni = g.index ? g.toNonIndexed() : g;
      const pa = ni.getAttribute('position');
      for (let i = 0; i < pa.count * 3; i++) colPos.push((pa.array as ArrayLike<number>)[i]);
      groups[Math.abs(Number(String(b.id).replace(/\D/g, '')) || 0) % 3].push(g);
      this.stats.buildings++;
    }
    groups.forEach((gs, i) => {
      if (!gs.length) return;
      const merged = mergeGeometries(gs, false);
      if (!merged) return;
      const m = new THREE.Mesh(merged, mats[i]); m.castShadow = true; m.receiveShadow = true;
      this.group.add(m);
    });
    const vertices = new Float32Array(colPos);
    const indices = new Uint32Array(vertices.length / 3);
    for (let i = 0; i < indices.length; i++) indices[i] = i;
    this.buildingCollider = { vertices, indices };
  }

  private buildLamps() {
    const spots: { x: number; z: number }[] = [];
    for (const r of this.map.roads) {
      if (r.kind === 'service' || r.kind === 'pedestrian') continue;
      let acc = 0, side = 1;
      for (let i = 0; i < r.points.length - 1; i++) {
        const [ax, az] = r.points[i], [bx, bz] = r.points[i + 1];
        const dx = bx - ax, dz = bz - az, l = Math.hypot(dx, dz);
        if (l === 0) continue;
        for (let d = (35 - acc) % 35; d < l; d += 35) {
          const t = d / l, off = r.width / 2 + 0.7 * 1;
          spots.push({ x: ax + dx * t + (-dz / l) * off * side, z: az + dz * t + (dx / l) * off * side });
          side = -side;
        }
        acc = (acc + l) % 35;
      }
    }
    const capped = spots.slice(0, 600);
    const pole = new THREE.CylinderGeometry(0.07, 0.09, 6, 6); pole.translate(0, 3, 0);
    const poleMesh = new THREE.InstancedMesh(pole, new THREE.MeshStandardMaterial({ color: 0x2b2b2e }), capped.length);
    const head = new THREE.SphereGeometry(0.25, 8, 6); head.translate(0, 6.1, 0);
    const headMesh = new THREE.InstancedMesh(head, this.lampMaterial, capped.length);
    const m = new THREE.Matrix4();
    capped.forEach((s, i) => { m.makeTranslation(s.x, this.terrain.heightAt(s.x, s.z) + 0.04, s.z); poleMesh.setMatrixAt(i, m); headMesh.setMatrixAt(i, m); });
    this.group.add(poleMesh, headMesh);
    this.stats.lamps = capped.length;
  }

  /** Spawn on the longest road; returns position + yaw (forward = +Z rotated by yaw about Y). */
  findSpawn(): { x: number; y: number; z: number; yaw: number } {
    let best = this.map.roads[0], bl = -1;
    for (const r of this.map.roads) {
      if (r.kind === 'pedestrian' || r.kind === 'service') continue;
      let l = 0; for (let i = 0; i < r.points.length - 1; i++) l += Math.hypot(r.points[i + 1][0] - r.points[i][0], r.points[i + 1][1] - r.points[i][1]);
      if (l > bl) { bl = l; best = r; }
    }
    const k = Math.floor((best.points.length - 1) / 2);
    const [ax, az] = best.points[k] as XZ, [bx, bz] = best.points[k + 1] as XZ;
    const x = (ax + bx) / 2, z = (az + bz) / 2;
    return { x, z, y: this.terrain.heightAt(x, z) + 1.2, yaw: Math.atan2(bx - ax, bz - az) };
  }
}
