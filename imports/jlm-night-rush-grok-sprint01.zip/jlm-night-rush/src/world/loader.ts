import type { GameMap } from './types';
import { validateMap } from './validate';

// All maps in src/data/maps are bundled statically (works from file:// in the single-file build).
const modules = import.meta.glob('../data/maps/*.json', { eager: true }) as Record<string, { default: GameMap }>;

/** Prefers a real (non-synthetic) map. Falls back to the synthetic test map. */
export function loadBestMap(): GameMap {
  const maps = Object.values(modules).map((m) => m.default).filter((m) => validateMap(m).length === 0);
  if (maps.length === 0) throw new Error('No valid map found in src/data/maps');
  return maps.find((m) => !m.meta.synthetic) ?? maps[0];
}
