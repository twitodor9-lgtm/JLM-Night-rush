import type { RoadWay, GameMap, XZ } from './types';

export interface GraphEdge { to: number; roadId: number | string; length: number; oneway: boolean }
export interface NearestRoad { road: RoadWay; distance: number; point: XZ; segment: number }

/**
 * Single road network used by: rendering, minimap, spawn search and (future) AI navigation.
 * Nodes are polyline vertices snapped to 0.5 m; shared vertices connect ways.
 */
export class RoadNetwork {
  roads: RoadWay[];
  nodes: XZ[] = [];
  adjacency: GraphEdge[][] = [];
  bounds = { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity };
  roadBounds: { minX: number; maxX: number; minZ: number; maxZ: number }[] = [];
  private nodeIndex = new Map<string, number>();

  constructor(map: Pick<GameMap, 'roads'>) {
    this.roads = map.roads;
    for (const r of this.roads) {
      const rb = { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity };
      let prev = -1;
      r.points.forEach(([x, z], i) => {
        rb.minX = Math.min(rb.minX, x); rb.maxX = Math.max(rb.maxX, x);
        rb.minZ = Math.min(rb.minZ, z); rb.maxZ = Math.max(rb.maxZ, z);
        const n = this.node(x, z);
        if (i > 0 && prev !== n) {
          const len = Math.hypot(x - this.nodes[prev][0], z - this.nodes[prev][1]);
          this.adjacency[prev].push({ to: n, roadId: r.id, length: len, oneway: r.oneway });
          if (!r.oneway) this.adjacency[n].push({ to: prev, roadId: r.id, length: len, oneway: false });
        }
        prev = n;
      });
      this.roadBounds.push(rb);
      this.bounds.minX = Math.min(this.bounds.minX, rb.minX - r.width); this.bounds.maxX = Math.max(this.bounds.maxX, rb.maxX + r.width);
      this.bounds.minZ = Math.min(this.bounds.minZ, rb.minZ - r.width); this.bounds.maxZ = Math.max(this.bounds.maxZ, rb.maxZ + r.width);
    }
  }

  private node(x: number, z: number): number {
    const key = `${Math.round(x * 2)},${Math.round(z * 2)}`;
    let id = this.nodeIndex.get(key);
    if (id === undefined) { id = this.nodes.length; this.nodes.push([x, z]); this.adjacency.push([]); this.nodeIndex.set(key, id); }
    return id;
  }

  nearestRoad(x: number, z: number): NearestRoad | null {
    let best: NearestRoad | null = null;
    this.roads.forEach((r, ri) => {
      const rb = this.roadBounds[ri];
      if (best && (x < rb.minX - best.distance || x > rb.maxX + best.distance || z < rb.minZ - best.distance || z > rb.maxZ + best.distance)) return;
      for (let i = 0; i < r.points.length - 1; i++) {
        const [ax, az] = r.points[i], [bx, bz] = r.points[i + 1];
        const dx = bx - ax, dz = bz - az, l2 = dx * dx + dz * dz;
        const t = l2 === 0 ? 0 : Math.max(0, Math.min(1, ((x - ax) * dx + (z - az) * dz) / l2));
        const px = ax + t * dx, pz = az + t * dz, d = Math.hypot(x - px, z - pz);
        if (!best || d < best.distance) best = { road: r, distance: d, point: [px, pz], segment: i };
      }
    });
    return best;
  }

  /** Connected-component count (diagnostic for data quality). */
  componentCount(): number {
    const seen = new Array(this.nodes.length).fill(false);
    let c = 0;
    for (let s = 0; s < this.nodes.length; s++) {
      if (seen[s]) continue;
      c++;
      const st = [s]; seen[s] = true;
      while (st.length) { const n = st.pop()!; for (const e of this.adjacency[n]) if (!seen[e.to]) { seen[e.to] = true; st.push(e.to); } }
    }
    return c;
  }
}
