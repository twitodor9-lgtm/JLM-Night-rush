export type RoadKind = 'motorway' | 'primary' | 'secondary' | 'tertiary' | 'residential' | 'service' | 'pedestrian';
export type XZ = [number, number];

export interface RoadWay {
  id: number | string;
  kind: RoadKind;
  name?: string;
  width: number;
  oneway: boolean;
  roundabout?: boolean;
  points: XZ[]; // local metres, +x east, -z north
}
export interface BuildingFootprint {
  id: number | string;
  height: number;
  heightSource: 'osm' | 'levels' | 'guess';
  footprint: XZ[];
}
export interface ElevationGrid {
  minX: number; minZ: number; cell: number; cols: number; rows: number;
  data: number[]; // metres relative to origin, row-major (z rows, x cols)
  source?: string;
}
export interface GameMap {
  meta: {
    name: string;
    synthetic: boolean; // true => NOT a real place
    origin: { lat: number; lon: number };
    source: string; license: string; generated: string; notes?: string;
  };
  roads: RoadWay[];
  buildings: BuildingFootprint[];
  elevation?: ElevationGrid;
}
