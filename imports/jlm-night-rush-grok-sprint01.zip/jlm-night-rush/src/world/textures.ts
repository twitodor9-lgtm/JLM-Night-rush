import * as THREE from 'three';

function canvasTex(size: number, draw: (c: CanvasRenderingContext2D, s: number) => void): THREE.CanvasTexture {
  const cv = document.createElement('canvas'); cv.width = cv.height = size;
  draw(cv.getContext('2d')!, size);
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}
const noise = (c: CanvasRenderingContext2D, s: number, n: number, a: number) => {
  for (let i = 0; i < n; i++) {
    const v = Math.random() * 255 | 0;
    c.fillStyle = `rgba(${v},${v},${v},${a})`;
    c.fillRect(Math.random() * s, Math.random() * s, 1 + Math.random() * 2, 1 + Math.random() * 2);
  }
};

/** Procedural (original, license-free) textures. 1 UV unit = 1 tile. */
export function asphaltTexture() {
  return canvasTex(256, (c, s) => { c.fillStyle = '#34363a'; c.fillRect(0, 0, s, s); noise(c, s, 5000, 0.25); });
}
export function stoneTexture(base = '#d9c7a0') {
  return canvasTex(256, (c, s) => {
    c.fillStyle = base; c.fillRect(0, 0, s, s);
    const rows = 8, h = s / rows;
    for (let r = 0; r < rows; r++) {
      const off = r % 2 ? s / 8 : 0;
      for (let x = -s / 4; x < s; x += s / 4) {
        const tone = 190 + Math.random() * 40 | 0;
        c.fillStyle = `rgb(${tone},${tone - 18},${tone - 55})`;
        c.fillRect(x + off + 2, r * h + 2, s / 4 - 4, h - 4);
      }
    }
    noise(c, s, 3000, 0.12);
  });
}
/** One facade tile = 4 m x 4 m: stone + a window. */
export function facadeTexture(tint: string) {
  return canvasTex(256, (c, s) => {
    c.fillStyle = tint; c.fillRect(0, 0, s, s);
    noise(c, s, 4000, 0.15);
    c.strokeStyle = 'rgba(80,60,30,.25)';
    for (let y = 0; y < s; y += 32) { c.beginPath(); c.moveTo(0, y); c.lineTo(s, y); c.stroke(); }
    c.fillStyle = '#26323f'; c.fillRect(s * 0.3, s * 0.25, s * 0.4, s * 0.5);
    c.strokeStyle = '#8a7650'; c.lineWidth = 6; c.strokeRect(s * 0.3, s * 0.25, s * 0.4, s * 0.5);
  });
}
/** Dashed centre-line, v along the road; period = 1 uv unit. */
export function dashTexture() {
  return canvasTex(64, (c, s) => { c.clearRect(0, 0, s, s); c.fillStyle = '#f2f2f2'; c.fillRect(0, 0, s, s * 0.5); });
}
