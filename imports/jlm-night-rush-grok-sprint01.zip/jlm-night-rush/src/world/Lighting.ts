import * as THREE from 'three';

/** Basic day / night. Lamp + headlight intensity follow the mode. */
export class Lighting {
  hemi = new THREE.HemisphereLight(0xcfe3ff, 0x6b5a45, 0.7);
  sun = new THREE.DirectionalLight(0xfff1d6, 2.4);
  headlights: THREE.SpotLight[] = [];
  lampMaterial = new THREE.MeshStandardMaterial({ color: 0x222222, emissive: 0xffd9a0, emissiveIntensity: 0.1 });
  night = false;

  constructor(private scene: THREE.Scene) {
    this.sun.position.set(120, 180, 80);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    const c = this.sun.shadow.camera; c.left = -70; c.right = 70; c.top = 70; c.bottom = -70; c.near = 10; c.far = 500;
    this.sun.shadow.bias = -0.0004;
    scene.add(this.hemi, this.sun, this.sun.target);
    this.set(false);
  }
  addHeadlight(l: THREE.SpotLight) { this.headlights.push(l); l.intensity = this.night ? 120 : 0; }
  followTarget(p: THREE.Vector3) {
    this.sun.target.position.copy(p);
    this.sun.position.copy(p).add(new THREE.Vector3(120, 180, 80));
  }
  toggle() { this.set(!this.night); }
  set(night: boolean) {
    this.night = night;
    const s = this.scene;
    if (night) {
      s.background = new THREE.Color(0x070b1a); s.fog = new THREE.Fog(0x070b1a, 40, 320);
      this.hemi.intensity = 0.28; this.hemi.color.set(0x5470a8);
      this.sun.color.set(0x7e96d0); this.sun.intensity = 0.35;
      this.lampMaterial.emissiveIntensity = 2.5;
    } else {
      s.background = new THREE.Color(0x9ec9ff); s.fog = new THREE.Fog(0x9ec9ff, 120, 700);
      this.hemi.intensity = 0.7; this.hemi.color.set(0xcfe3ff);
      this.sun.color.set(0xfff1d6); this.sun.intensity = 2.4;
      this.lampMaterial.emissiveIntensity = 0.1;
    }
    this.headlights.forEach((l) => (l.intensity = night ? 120 : 0));
  }
}
