import type { GameMap } from './types';

export function validateMap(m: unknown): string[] {
  const e: string[] = [];
  const g = m as GameMap;
  if (!g || typeof g !== 'object') return ['map is not an object'];
  if (!g.meta || typeof g.meta.synthetic !== 'boolean') e.push('meta.synthetic missing');
  if (!Array.isArray(g.roads) || g.roads.length === 0) e.push('roads missing/empty');
  else g.roads.forEach((r, i) => {
    if (!Array.isArray(r.points) || r.points.length < 2) e.push(`road[${i}] needs >=2 points`);
    if (!(r.width > 0)) e.push(`road[${i}] bad width`);
  });
  if (!Array.isArray(g.buildings)) e.push('buildings missing');
  if (g.elevation) {
    const el = g.elevation;
    if (el.data.length !== el.cols * el.rows) e.push('elevation size mismatch');
  }
  return e;
}
