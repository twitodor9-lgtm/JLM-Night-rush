import * as THREE from 'three';
import type { ElevationGrid } from './types';

export interface Bounds { minX: number; maxX: number; minZ: number; maxZ: number }

export class Terrain {
  constructor(private grid?: ElevationGrid) {}

  /** Bilinear height in metres (0 if no elevation data). */
  heightAt(x: number, z: number): number {
    const g = this.grid;
    if (!g || g.cols < 2 || g.rows < 2) return g?.data[0] ?? 0;
    const fx = Math.min(Math.max((x - g.minX) / g.cell, 0), g.cols - 1);
    const fz = Math.min(Math.max((z - g.minZ) / g.cell, 0), g.rows - 1);
    const i = Math.min(Math.floor(fx), g.cols - 2), j = Math.min(Math.floor(fz), g.rows - 2);
    const tx = fx - i, tz = fz - j;
    const h = (a: number, b: number) => g.data[b * g.cols + a];
    return (h(i, j) * (1 - tx) + h(i + 1, j) * tx) * (1 - tz) + (h(i, j + 1) * (1 - tx) + h(i + 1, j + 1) * tx) * tz;
  }

  buildGeometry(b: Bounds, cell = 8): { geometry: THREE.BufferGeometry; vertices: Float32Array; indices: Uint32Array } {
    const cols = Math.ceil((b.maxX - b.minX) / cell) + 1;
    const rows = Math.ceil((b.maxZ - b.minZ) / cell) + 1;
    const vertices = new Float32Array(cols * rows * 3);
    const uv = new Float32Array(cols * rows * 2);
    for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
      const x = b.minX + i * cell, z = b.minZ + j * cell, k = j * cols + i;
      vertices.set([x, this.heightAt(x, z), z], k * 3);
      uv.set([x / 6, z / 6], k * 2);
    }
    const indices = new Uint32Array((cols - 1) * (rows - 1) * 6);
    let n = 0;
    for (let j = 0; j < rows - 1; j++) for (let i = 0; i < cols - 1; i++) {
      const a = j * cols + i, bb = (j + 1) * cols + i, c = a + 1, d = bb + 1;
      indices.set([a, bb, c, c, bb, d], n); n += 6;
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
    geometry.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    geometry.setIndex(new THREE.BufferAttribute(indices, 1));
    geometry.computeVertexNormals();
    return { geometry, vertices, indices };
  }
}
