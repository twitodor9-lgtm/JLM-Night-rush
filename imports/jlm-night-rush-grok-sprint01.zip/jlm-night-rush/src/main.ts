import * as THREE from 'three';
import { loadBestMap } from './world/loader';
import { World } from './world/World';
import { Lighting } from './world/Lighting';
import { PhysicsWorld, STEP } from './physics/PhysicsWorld';
import { Vehicle } from './vehicle/Vehicle';
import { DEFAULT_TUNING } from './vehicle/tuning';
import { Input } from './input/Input';
import { ChaseCamera } from './camera/ChaseCamera';
import { Hud, buildTuningPanel } from './ui/Hud';
import { Minimap } from './ui/Minimap';

async function main() {
  const canvas = document.getElementById('game') as HTMLCanvasElement;
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true }); // three r163+ is WebGL2-only
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(62, 1, 0.3, 1500);
  const resize = () => { renderer.setSize(innerWidth, innerHeight, false); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); };
  addEventListener('resize', resize); resize();

  const map = loadBestMap();
  const lighting = new Lighting(scene);
  const world = new World(map, lighting.lampMaterial);
  scene.add(world.group);

  const physics = await PhysicsWorld.create();
  physics.addStaticTrimesh(world.groundCollider.vertices, world.groundCollider.indices, 1.0);
  physics.addStaticTrimesh(world.buildingCollider.vertices, world.buildingCollider.indices, 0.3);

  const tuning = { ...DEFAULT_TUNING };
  const vehicle = new Vehicle(physics, tuning, world.findSpawn());
  scene.add(vehicle.object);
  lighting.addHeadlight(vehicle.headlight);

  const input = new Input();
  const chase = new ChaseCamera(camera);
  const hud = new Hud(() => tuning.maxSpeedKmh);
  const panel = buildTuningPanel(tuning, (t) => vehicle.applyTuning(t));
  const minimap = new Minimap(document.getElementById('minimap') as HTMLCanvasElement, world);
  input.onReset = () => vehicle.reset();
  input.onToggleNight = () => lighting.toggle();
  input.onToggleTuning = panel.toggle;

  if (map.meta.synthetic) hud.banner('SYNTHETIC TEST MAP — NOT JERUSALEM. Run "npm run map:fetch && npm run map:build" to generate real OSM data.');
  else hud.banner(`${map.meta.name} — ${map.meta.source}`);
  document.getElementById('loading')!.remove();

  let acc = 0, last = performance.now(), flipT = 0, frame = 0;
  const loop = (now: number) => {
    const dt = Math.min((now - last) / 1000, 0.1); last = now;
    acc += dt;
    const ctl = input.state();
    while (acc >= STEP) { vehicle.preStep(STEP, ctl); physics.step(); acc -= STEP; }
    vehicle.sync();
    flipT = vehicle.isFlipped() ? flipT + dt : 0;
    if (flipT > 3) { vehicle.reset(); flipT = 0; }
    chase.update(dt, vehicle.object, vehicle.heading(), vehicle.speedKmh);
    lighting.followTarget(vehicle.object.position);
    const h = vehicle.heading();
    if ((frame++ & 1) === 0) minimap.draw(vehicle.object.position.x, vehicle.object.position.z, h.x, h.z);
    const near = world.network.nearestRoad(vehicle.object.position.x, vehicle.object.position.z);
    hud.update(vehicle.speedKmh, `Road: ${near?.road.name ?? near?.road.kind ?? '-'} (${near ? near.distance.toFixed(0) : '-'} m)\nRoads ${world.stats.roads} · Buildings ${world.stats.buildings} · Lamps ${world.stats.lamps}`);
    renderer.render(scene, camera);
    requestAnimationFrame(loop);
  };
  requestAnimationFrame(loop);
}
main().catch((e) => { document.getElementById('loading')!.textContent = 'Error: ' + (e?.message ?? e); console.error(e); });
