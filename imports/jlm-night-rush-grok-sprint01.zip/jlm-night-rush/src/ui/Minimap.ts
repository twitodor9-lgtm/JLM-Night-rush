import type { World } from '../world/World';

/** Circular heading-up minimap drawn from the same RoadNetwork + building footprints used by the 3D world. */
export class Minimap {
  private ctx: CanvasRenderingContext2D;
  private centroids: { x: number; z: number }[];
  scale = 1.1; // px per metre in canvas pixels (canvas is 340 px)
  constructor(private cv: HTMLCanvasElement, private world: World) {
    this.ctx = cv.getContext('2d')!;
    this.centroids = world.map.buildings.map((b) => {
      let x = 0, z = 0; b.footprint.forEach((p) => { x += p[0]; z += p[1]; });
      return { x: x / b.footprint.length, z: z / b.footprint.length };
    });
  }
  draw(x: number, z: number, hx: number, hz: number) {
    const c = this.ctx, W = this.cv.width, s = this.scale, R = W / 2 / s + 20;
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.clearRect(0, 0, W, W);
    c.save();
    c.beginPath(); c.arc(W / 2, W / 2, W / 2 - 2, 0, Math.PI * 2); c.clip();
    c.fillStyle = '#10151f'; c.fillRect(0, 0, W, W);
    c.translate(W / 2, W / 2);
    c.rotate(-Math.PI / 2 - Math.atan2(hz, hx));
    c.scale(s, s);
    c.translate(-x, -z);
    c.fillStyle = '#2a3140';
    this.world.map.buildings.forEach((b, i) => {
      const cc = this.centroids[i];
      if (Math.abs(cc.x - x) > R || Math.abs(cc.z - z) > R) return;
      c.beginPath(); b.footprint.forEach((p, k) => (k ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.closePath(); c.fill();
    });
    c.lineCap = 'round'; c.lineJoin = 'round'; c.strokeStyle = '#9aa7bd';
    const net = this.world.network;
    net.roads.forEach((r, i) => {
      const b = net.roadBounds[i];
      if (b.maxX < x - R || b.minX > x + R || b.maxZ < z - R || b.minZ > z + R) return;
      c.lineWidth = Math.max(r.width, 3 / s);
      c.beginPath(); r.points.forEach((p, k) => (k ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.stroke();
    });
    c.restore();
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.fillStyle = '#ffcc33'; c.strokeStyle = '#000'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(W / 2, W / 2 - 14); c.lineTo(W / 2 + 9, W / 2 + 11); c.lineTo(W / 2 - 9, W / 2 + 11); c.closePath(); c.fill(); c.stroke();
  }
}
