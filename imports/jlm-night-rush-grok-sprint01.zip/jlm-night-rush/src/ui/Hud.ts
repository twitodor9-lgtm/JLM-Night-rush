import type { VehicleTuning } from '../vehicle/tuning';
import { TUNING_FIELDS } from '../vehicle/tuning';

export class Hud {
  private speed = document.getElementById('speed')!;
  private bar = document.getElementById('speedbar') as HTMLElement;
  private info = document.getElementById('info')!;
  private frames = 0; private t0 = performance.now(); fps = 0;
  constructor(private maxKmh: () => number) {}
  update(kmh: number, extra: string) {
    this.speed.textContent = String(Math.round(Math.abs(kmh)));
    this.bar.style.width = `${Math.min(Math.abs(kmh) / this.maxKmh(), 1) * 100}%`;
    this.frames++;
    const now = performance.now();
    if (now - this.t0 > 500) { this.fps = (this.frames * 1000) / (now - this.t0); this.frames = 0; this.t0 = now; }
    this.info.textContent = `WASD/arrows drive · Space handbrake · R reset · N day/night · T tuning\nFPS ${this.fps.toFixed(0)} (measured on this device)\n${extra}`;
  }
  banner(text: string) { const b = document.getElementById('banner')!; b.textContent = text; b.style.display = 'block'; }
}

export function buildTuningPanel(t: VehicleTuning, onChange: (t: VehicleTuning) => void) {
  const el = document.getElementById('tuning')!;
  el.innerHTML = '<b>Driving parameters</b>';
  for (const f of TUNING_FIELDS) {
    const label = document.createElement('label');
    const val = document.createElement('span');
    const input = document.createElement('input');
    input.type = 'range'; input.min = String(f.min); input.max = String(f.max); input.step = String(f.step);
    input.value = String(t[f.key]); val.textContent = ` ${t[f.key]}`;
    input.addEventListener('input', () => { (t as unknown as Record<string, number>)[f.key] = Number(input.value); val.textContent = ` ${input.value}`; onChange(t); });
    label.append(f.label, val, input); el.append(label);
  }
  return { toggle: () => { el.style.display = el.style.display === 'block' ? 'none' : 'block'; } };
}
