export interface ControlState { throttle: number; brake: number; steer: number; handbrake: boolean } // steer: +1 = right

/** Keyboard + touch merged. Edge actions via callbacks. */
export class Input {
  private keys = new Set<string>();
  private touch = { left: false, right: false, gas: false, brake: false, hand: false };
  onReset = () => {}; onToggleNight = () => {}; onToggleTuning = () => {};

  constructor() {
    addEventListener('keydown', (e) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      this.keys.add(e.code);
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
      if (e.repeat) return;
      if (e.code === 'KeyR') this.onReset();
      if (e.code === 'KeyN') this.onToggleNight();
      if (e.code === 'KeyT') this.onToggleTuning();
    });
    addEventListener('keyup', (e) => this.keys.delete(e.code));
    addEventListener('blur', () => this.keys.clear());
    if (matchMedia('(pointer: coarse)').matches) document.body.classList.add('coarse');
    document.querySelectorAll<HTMLButtonElement>('.touch button').forEach((b) => {
      const k = b.dataset.k as keyof typeof this.touch;
      const set = (v: boolean) => (e: Event) => { e.preventDefault(); this.touch[k] = v; };
      b.addEventListener('pointerdown', set(true));
      for (const ev of ['pointerup', 'pointercancel', 'pointerleave']) b.addEventListener(ev, set(false));
    });
  }

  state(): ControlState {
    const k = (c: string) => this.keys.has(c);
    const left = k('KeyA') || k('ArrowLeft') || this.touch.left;
    const right = k('KeyD') || k('ArrowRight') || this.touch.right;
    return {
      throttle: k('KeyW') || k('ArrowUp') || this.touch.gas ? 1 : 0,
      brake: k('KeyS') || k('ArrowDown') || this.touch.brake ? 1 : 0,
      steer: (right ? 1 : 0) - (left ? 1 : 0),
      handbrake: k('Space') || this.touch.hand,
    };
  }
}
