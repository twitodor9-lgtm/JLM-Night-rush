# Known issues / not done

Updated 2026-10-17 (Grok sprint 01).

## Runtime verification status
- **Install / typecheck / build / browser test could not be completed** inside the constrained sandbox (repeated incomplete `npm install` of Rapier WASM + Vite tree under memory/timeout pressure).
- Source-level review + two targeted fixes performed. A normal developer machine must run:
  ```bash
  npm install
  npm run typecheck
  npm test
  npm run dev          # or npm run build:single
  ```
  and perform the manual driving checklist in `TEST_RESULTS.md`.

## Honest status vs. the task
- Costa Vista (MIT) was **not reviewed or ported**. Vehicle is a fresh Rapier `DynamicRayCastVehicleController` implementation. Keep MIT notice if ported later.
- **No real Jerusalem data is included.** Only the synthetic test map (red banner). Scripts `map:fetch` / `map:build` are present and ready for a machine with network.
- Centre coordinates in `scripts/area.config.json` are approximate.
- Overpass / elevation scripts untested end-to-end.
- No GitHub interaction (per instructions).

## Technical gaps still open
- Rapier axis/sign conventions (drive, steer, wheel spin) reasoned from docs but **unverified in browser** → use T panel to flip `driveSign` / `steerSign` on first run, then hard-code the correct defaults.
- Junctions / roundabouts = overlapping ribbons (layered by class), not true junction meshes; sidewalks have no curb height.
- Collision = terrain trimesh + building trimesh only (no curbs/barriers). Roads drawn ~6–10 cm above physics ground.
- Elevation absent on synthetic map → completely flat. Real OSM maps will use coarse DEM if generated.
- Building heights: OSM values when present, otherwise placeholders. No roofs / courtyards / multipolygon holes.
- Textures = simple procedural canvases. Night windows not lit individually. Limited lamp posts (emissive only).
- Minimap redraws every 2nd frame, no caching. Shadow map 2048 may be heavy on low-end devices.
- No automated physics / rendering tests beyond the pure unit tests in `tests/core.test.ts`.
- Single-file build (`build:single`) not exercised; expected to work once deps install cleanly.

## Fixes already applied (see CHANGELOG.md)
- Building collision trimesh now uses `toNonIndexed()` so triangles are valid.
- Vehicle `reset()` fully clears forces, wheel forces and internal state.

## Recommended next three tasks
1. On a normal machine: `npm install && npm run dev`, confirm the car moves in world space, fix drive/steer signs, then `npm run build:single` and verify the standalone HTML.
2. Generate a real Jerusalem extract around First Station / Remez / Hebron Road and verify spawn + road alignment.
3. Add simple automated “vehicle actually advanced / turned / stopped” checks that can run under Vitest + a headless Rapier step (no renderer required).
