# CHANGELOG — Grok Development Sprint 01 (2026-10-17)

## Fixed

### src/world/World.ts
- **Building collider trimesh correctness**  
  Previously: position attribute of indexed ExtrudeGeometry was dumped and sequential indices invented → invalid / degenerate collision triangles.  
  Now: each building geometry is converted with `toNonIndexed()` before vertex collection so Rapier receives proper triangle soup.

### src/vehicle/Vehicle.ts
- **Reset completeness**  
  `reset()` now also clears forces/torques, internal steer & speed state, and explicitly zeroes engine force / brake / steering on every wheel. Prevents residual drive forces after R-key or auto-flip recovery.

## Unchanged (by design)
- Core architecture (Three.js + Rapier DynamicRayCastVehicleController, synthetic map, Vite single-file option, OSM scripts).
- Default tuning values (`driveSign: 1`, `steerSign: -1`).
- Input, camera, HUD, minimap, lighting, road/terrain generation.
- No graphics overhaul (Checkpoint D deferred until driving is verified).
- No real Jerusalem OSM data bundled (only synthetic test map; scripts ready for offline generation).

## Environment note
Full `npm install` / typecheck / build / browser test could not be completed inside the constrained sandbox. Source changes are minimal and targeted; the tree is intended to build cleanly on a normal Node 18+/20+ environment.
