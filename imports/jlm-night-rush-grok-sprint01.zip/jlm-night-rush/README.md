# JLM Night Rush — Engine v1 (Claude branch: `feature/claude-engine-v1`)

3D street-racing foundation: **Three.js + Rapier + TypeScript + Vite**, with an offline OpenStreetMap pipeline.

> ## ⚠️ STATUS: WRITTEN, NOT YET RUN
> This code was produced in a sandbox with **no network, no npm, no browser**. It has **not been installed,
> type-checked, built, tested or opened in a browser**. Expect a first round of small compile/runtime fixes.
> Nothing below is a measured result. See `KNOWN_ISSUES.md`.

## Quick start (developer, once)
```bash
npm install
npm run map:synthetic     # (already included) synthetic test map, flagged NOT Jerusalem
npm run dev               # http://localhost:5173
npm test                  # vitest unit tests (never executed yet)
```

## Real Jerusalem data (needs internet, one time)
```bash
npm run map:fetch         # Overpass -> data/raw/osm-raw.json   (centre in scripts/area.config.json is APPROXIMATE — verify)
npm run map:build         # -> src/data/maps/jerusalem-first-station.json (+ DEM elevation, ~90 m resolution)
```
The game auto-prefers any non-synthetic map in `src/data/maps/`. Until you build one, a red banner says
**"SYNTHETIC TEST MAP — NOT JERUSALEM"**. The game never calls Overpass at runtime.

## Distribution without Node for players
- `npm run build:single` → **`dist/index.html`**: one self-contained file (map JSON + Rapier WASM inlined), opens by double click, works offline. Expect a few MB. If it gets too large with a big city, the alternative is the normal `npm run build` (`dist/` folder) hosted on GitHub Pages — `.github/workflows/pages.yml` builds both and publishes the single-file as a CI artifact.

## Controls
WASD / arrows drive · Space handbrake (rear grip drops → drift) · R reset · N day/night · T tuning panel. Touch buttons appear on touch devices.
**First run: verify** the car accelerates forward and steers the right way; if not, flip `driveSign` / `steerSign` in the tuning panel (T) and fix the defaults in `src/vehicle/tuning.ts`.

## Architecture
| Folder | Role |
|---|---|
| `src/world` | `types` (GameMap format), `projection`, `roadNetwork` (graph; shared by render/minimap/spawn/future AI), `terrain`, `roadMesh`, `World` (builds roads, sidewalks, lane lines, buildings, lamps + collision meshes), `Lighting`, `textures` (procedural, license-free), `loader`, `validate` |
| `src/physics` | `PhysicsWorld` — Rapier init, fixed 60 Hz step, static trimesh colliders |
| `src/vehicle` | `Vehicle` (Rapier raycast vehicle: 4 wheels, suspension, RWD, handbrake drift) + `tuning` (all parameters, shown as sliders) |
| `src/input` | keyboard + touch |
| `src/camera` | yaw-smoothed chase camera |
| `src/ui` | speedometer/HUD, tuning panel, circular heading-up minimap |
| `scripts` | `fetch-osm`, `build-map`, `make-synthetic-map`, `push-branch.sh` |
| `tests` | vitest: projection, road graph, terrain, map validation, tuning ranges |

## Roadmap (suggested order)
1. `npm install && npm run dev`; fix compile errors; verify drive/steer signs and suspension feel.
2. Build real map; check alignment/orientation; check spawn on a real road.
3. Proper junction polygons + curbs; collision for curbs/barriers.
4. Better elevation (SRTM/Israel DTM, LiDAR if licensed) and road-profile smoothing.
5. AI cars on `RoadNetwork` graph (A*), then Kart mode (same maps, different `VehicleTuning`).
6. Performance pass with *measured* numbers (chunking, instancing, LOD).

## Licenses
See `THIRD_PARTY_LICENSES.md`. Map data © OpenStreetMap contributors (ODbL) — attribution required.
